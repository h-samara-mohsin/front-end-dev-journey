var fname = document.getElementById("f-name");
var lname = document.getElementById("l-name");
var email = document.getElementById("email-label");
var company = document.getElementById("company-label");
var countryLabel = document.getElementById("country-label");

var textfname = document.getElementById("firstname");
var textlname = document.getElementById("lastname");
var textemail = document.getElementById("email");
var textcompany = document.getElementById("company");
var countrySelect = document.getElementById("country");



function labelmove(inputname) {
    if (inputname == "firstname") {
        fname.style.transition = "all 0.2s";
        fname.style.marginTop = "-15px";
        fname.style.marginLeft = "10px";
        fname.style.zIndex = "10";
        fname.style.transform = "scale(0.9)";
        fname.style.padding = "5px 4px 5px 4px";
        fname.style.background = "#306f62";
        fname.style.fontSize = "13px"
        fname.style.opacity = "1";
    }
    if (inputname == "lastname") {
        lname.style.transition = "all 0.2s";
        lname.style.marginTop = "-15px";
        lname.style.marginLeft = "10px";
        lname.style.zIndex = "10";
        lname.style.transform = "scale(0.9)";
        lname.style.padding = "5px 4px 5px 4px";
        lname.style.background = "#306f62";
        lname.style.fontSize = "13px"
        lname.style.opacity = "1";
    }
    if (inputname == "email") {
        email.style.transition = "all 0.2s";
        email.style.marginTop = "-15px";
        email.style.marginLeft = "10px";
        email.style.zIndex = "10";
        email.style.transform = "scale(0.9)";
        email.style.padding = "5px 4px 5px 4px";
        email.style.background = "#306f62";
        email.style.fontSize = "13px"
        email.style.opacity = "1";
    }
    if (inputname == "company") {
        company.style.transition = "all 0.2s";
        company.style.marginTop = "-15px";
        company.style.marginLeft = "10px";
        company.style.zIndex = "10";
        company.style.transform = "scale(0.9)";
        company.style.padding = "5px 4px 5px 4px";
        company.style.background = "#306f62";
        company.style.fontSize = "13px"
        company.style.opacity = "1";
    }
    if (inputname == "country") {
        countryLabel.style.transition = "all 0.2s";
        countryLabel.style.marginTop = "-15px";
        countryLabel.style.marginLeft = "10px";
        countryLabel.style.zIndex = "10";
        countryLabel.style.transform = "scale(0.9)";
        countryLabel.style.padding = "5px 4px 5px 4px";
        countryLabel.style.background = "#306f62";
        countryLabel.style.fontSize = "13px";
        countryLabel.style.opacity = "1";
    }
}

window.onclick = function (event) {
    if (event.target != textfname && textfname.value.length == 0) {
        fname.style.transform = "scale(1)";
        fname.style.transition = "all 0.2s";
        fname.style.marginTop = "9px";
        fname.style.marginLeft = "10px";
        fname.style.zIndex = "0";
        fname.style.padding = "0px";
        fname.style.backgroundColor = "transparent";
        fname.style.fontSize = "16px";
        fname.style.opacity = "0.7"
    }
    if (event.target != textlname && textlname.value.length == 0) {
        lname.style.transform = "scale(1)";
        lname.style.transition = "all 0.2s";
        lname.style.marginTop = "9px";
        lname.style.marginLeft = "10px";
        lname.style.zIndex = "0";
        lname.style.padding = "0px";
        lname.style.backgroundColor = "transparent";
        lname.style.fontSize = "16px";
        lname.style.opacity = "0.7"
    }
    if (event.target != textemail && textemail.value.length == 0) {
        email.style.transform = "scale(1)";
        email.style.transition = "all 0.2s";
        email.style.marginTop = "9px";
        email.style.marginLeft = "10px";
        email.style.zIndex = "0";
        email.style.padding = "0px";
        email.style.backgroundColor = "transparent";
        email.style.fontSize = "16px";
        email.style.opacity = "0.7";
    }
    if (event.target != textcompany && textcompany.value.length == 0) {
        company.style.transform = "scale(1)";
        company.style.transition = "all 0.2s";
        company.style.marginTop = "9px";
        company.style.marginLeft = "10px";
        company.style.zIndex = "0";
        company.style.padding = "0px";
        company.style.backgroundColor = "transparent";
        company.style.fontSize = "16px";
        company.style.opacity = "0.7";
    }
    if (event.target != countrySelect && countrySelect.value == "") {
        countryLabel.style.transform = "scale(1)";
        countryLabel.style.transition = "all 0.2s";
        countryLabel.style.marginTop = "9px";
        countryLabel.style.marginLeft = "10px";
        countryLabel.style.zIndex = "0";
        countryLabel.style.padding = "0px";
        countryLabel.style.backgroundColor = "transparent";
        countryLabel.style.fontSize = "16px";
        countryLabel.style.opacity = "0.7";
    }
}

// Carousel JS

let currentSlide = 0;
  const dots = document.querySelectorAll('.dot');
  const carousel = document.getElementById('carousel');

  const slides = [
  {
    name: 'Abbie Harvey',
    text: 'I have been caring for my mom & dad off and on for about 10 years now, and I know the importance of me being there for appointments. Older people need attention, love and care that they truly deserve.',
    image: './assets/carousel-assets/Mask Group.png' // NEW Image
  },
  {
    name: 'James Smith',
    text: 'Supporting my grandparents taught me the value of patience and empathy. I try to be there every weekend to spend quality time and assist with anything they need.',
    image: './assets/carousel-assets/Mask Group (1).png' // NEW Image
  },
  {
    name: 'Emily Rose',
    text: 'Caring for elders has helped me grow emotionally and mentally. It’s all about giving back love and time to the ones who raised us.',
    image: './assets/carousel-assets/Mask Group (2).png' // NEW Image
  }
];

  function renderSlide(index) {
  const { name, text, image } = slides[index];

  const imgEl = carousel.querySelector('.testimonial-img img');
  const nameEl = carousel.querySelector('.testimonial-content h3');
  const textEl = carousel.querySelector('.testimonial-content p');

  imgEl.src = image;
  nameEl.textContent = name;
  textEl.textContent = text;

  // Dots active class
  dots.forEach(dot => dot.classList.remove('active'));
  dots[index].classList.add('active');
}


  function nextSlide() {
    currentSlide = (currentSlide + 1) % slides.length;
    renderSlide(currentSlide);
  }

  function prevSlide() {
    currentSlide = (currentSlide - 1 + slides.length) % slides.length;
    renderSlide(currentSlide);
    console.log("Pressed");
  }

  function goToSlide(index) {
    currentSlide = index;
    renderSlide(index);
  }